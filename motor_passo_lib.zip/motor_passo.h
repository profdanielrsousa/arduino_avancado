/* NONO EXEMPLO - BIBLIOTECA MOTOR DE PASSO (ARQUIVO DE CABEÇALHO)
   DANIEL RODRIGUES DE SOUSA 27/09/2019 */

#ifndef MOTOR_PASSO_H  // Diretiva de guarda para evitar inclusão múltipla do cabeçalho
#define MOTOR_PASSO_H

#include <Arduino.h>  // Inclui as definições e funções padrão do núcleo Arduino

#define MOTOR_PARADO        0  // Define o estado de motor parado
#define MOTOR_HORARIO       1  // Define o sentido de rotação horário
#define MOTOR_ANTI_HORARIO  2  // Define o sentido de rotação anti-horário

#define PASSO_COMPLETO      0  // Define o modo de acionamento em passo completo
#define MEIO_PASSO          1  // Define o modo de acionamento em meio passo

#ifndef BOBINA1  // Verifica se os pinos das bobinas já foram definidos no código principal

#define BOBINA1   2  // Definição padrão do pino da bobina 1 do motor de passo
#define BOBINA2   3  // Definição padrão do pino da bobina 2 do motor de passo
#define BOBINA3   4  // Definição padrão do pino da bobina 3 do motor de passo
#define BOBINA4   5  // Definição padrão do pino da bobina 4 do motor de passo

#endif  // Encerra a verificação condicional de definição dos pinos das bobinas

// Tabela de sequência de acionamento para motor unipolar em meio passo (8 estados)
const char motor_unipolar_meio_passo[ 8 ] = { 0b00001000, 
                                              0b00001100, 
                                              0b00000100, 
                                              0b00000110, 
                                              0b00000010, 
                                              0b00000011, 
                                              0b00000001, 
                                              0b00001001 };

// Tabela de sequência de acionamento para motor unipolar em passo completo (4 estados)
const char motor_unipolar_passo_comp[ 4 ] = { 0b00001000,
                                              0b00000100,
                                              0b00000010,
                                              0b00000001 };

// Tabela de sequência de acionamento para motor bipolar em meio passo (8 estados)
const char motor_bipolar_meio_passo[ 8 ] =  { 0b00001001,
                                              0b00001000,
                                              0b00001010,
                                              0b00000010,
                                              0b00000110,
                                              0b00000100,
                                              0b00000101,
                                              0b00000001 };

// Tabela de sequência de acionamento para motor bipolar em passo completo (4 estados)
const char motor_bipolar_passo_comp[ 4 ] =  { 0b00001010,
                                              0b00001001,
                                              0b00000101,
                                              0b00000110 };

extern unsigned char state_motor_controle;  // Declaração externa da variável de controle de direção do motor

void motor_passo_unipolar( unsigned int numero_passos, unsigned int tempo, unsigned modo, unsigned char sentido );  // Prototipagem das funções públicas da biblioteca
void motor_passo_bipolar( unsigned int numero_passos, unsigned int tempo, unsigned modo, unsigned char sentido );
void sm_motor_passo_unipolar_passo_comp( void );
void sm_motor_passo_unipolar_meio_passo( void );
void sm_motor_passo_bipolar_passo_comp( void );
void sm_motor_passo_bipolar_meio_passo( void );
void motor_passo_inicializacao( void );
void motor_passo( char motor );

#endif  // Encerra a diretiva de guarda MOTOR_PASSO_H